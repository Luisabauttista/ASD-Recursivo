#Ejercicio 2

def calcular_first(gramatica):
    first = {nt: set() for nt in gramatica}
    
    cambio = True
    while cambio:
        cambio = False
        
        for nt in gramatica:
            for prod in gramatica[nt]:
                for simbolo in prod:
                    
                    if simbolo not in gramatica:
                        if simbolo not in first[nt]:
                            first[nt].add(simbolo)
                            cambio = True
                        break
                    
                    antes = len(first[nt])
                    first[nt] |= (first[simbolo] - {'ε'})
                    
                    if 'ε' not in first[simbolo]:
                        break
                    
                    if antes != len(first[nt]):
                        cambio = True
                else:
                    if 'ε' not in first[nt]:
                        first[nt].add('ε')
                        cambio = True
    
    return first


def calcular_follow(gramatica, first):
    follow = {nt: set() for nt in gramatica}
    
    inicio = list(gramatica.keys())[0]
    follow[inicio].add('$')
    
    cambio = True
    
    while cambio:
        cambio = False
        
        for nt in gramatica:
            for prod in gramatica[nt]:
                
                for i in range(len(prod)):
                    simbolo = prod[i]
                    
                    if simbolo in gramatica:
                        siguiente = prod[i+1:]
                        
                        if siguiente:
                            temp = set()
                            j = 0
                            
                            while True:
                                s = siguiente[j]
                                
                                if s not in gramatica:
                                    temp.add(s)
                                    break
                                
                                temp |= (first[s] - {'ε'})
                                
                                if 'ε' not in first[s]:
                                    break
                                
                                j += 1
                                if j >= len(siguiente):
                                    temp |= follow[nt]
                                    break
                            
                            antes = len(follow[simbolo])
                            follow[simbolo] |= temp
                            
                            if antes != len(follow[simbolo]):
                                cambio = True
                        
                        else:
                            antes = len(follow[simbolo])
                            follow[simbolo] |= follow[nt]
                            
                            if antes != len(follow[simbolo]):
                                cambio = True
    
    return follow

gramatica = {
    'S': [['A', 'B', 'uno']],
    'A': [['dos', 'B'], ['ε']],
    'B': [['C', 'D'], ['tres'], ['ε']],
    'C': [['cuatro', 'A', 'B'], ['cinco']],
    'D': [['seis'], ['ε']]
}

first = calcular_first(gramatica)
follow = calcular_follow(gramatica, first)

print("FOLLOW:")
for k, v in follow.items():
    print(k, ":", v)