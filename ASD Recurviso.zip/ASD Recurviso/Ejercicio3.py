#Ejercicio 3
def calcular_first(gramatica):
    first = {nt: set() for nt in gramatica}
    
    cambio = True
    while cambio:
        cambio = False
        
        for nt in gramatica:
            for prod in gramatica[nt]:
                for simbolo in prod:
                    
                    if simbolo not in gramatica:
                        if simbolo not in first[nt]:
                            first[nt].add(simbolo)
                            cambio = True
                        break
                    
                    antes = len(first[nt])
                    first[nt] |= (first[simbolo] - {'ε'})
                    
                    if 'ε' not in first[simbolo]:
                        break
                    
                    if antes != len(first[nt]):
                        cambio = True
                else:
                    if 'ε' not in first[nt]:
                        first[nt].add('ε')
                        cambio = True
    
    return first


def calcular_follow(gramatica, first):
    follow = {nt: set() for nt in gramatica}
    
    inicio = list(gramatica.keys())[0]
    follow[inicio].add('$')
    
    cambio = True
    
    while cambio:
        cambio = False
        
        for nt in gramatica:
            for prod in gramatica[nt]:
                
                for i in range(len(prod)):
                    simbolo = prod[i]
                    
                    if simbolo in gramatica:
                        siguiente = prod[i+1:]
                        
                        if siguiente:
                            temp = set()
                            j = 0
                            
                            while True:
                                s = siguiente[j]
                                
                                if s not in gramatica:
                                    temp.add(s)
                                    break
                                
                                temp |= (first[s] - {'ε'})
                                
                                if 'ε' not in first[s]:
                                    break
                                
                                j += 1
                                if j >= len(siguiente):
                                    temp |= follow[nt]
                                    break
                            
                            follow[simbolo] |= temp
                        
                        else:
                            follow[simbolo] |= follow[nt]
    
    return follow


def first_de_cadena(cadena, first, gramatica):
    resultado = set()
    
    i = 0
    while True:
        simbolo = cadena[i]
        
        if simbolo not in gramatica:
            resultado.add(simbolo)
            break
        
        resultado |= (first[simbolo] - {'ε'})
        
        if 'ε' not in first[simbolo]:
            break
        
        i += 1
        if i >= len(cadena):
            resultado.add('ε')
            break
    
    return resultado


def calcular_predict(gramatica, first, follow):
    predict = {}
    
    for nt in gramatica:
        for prod in gramatica[nt]:
            
            clave = f"{nt} -> {' '.join(prod)}"
            primeros = first_de_cadena(prod, first, gramatica)
            
            if 'ε' in primeros:
                predict[clave] = (primeros - {'ε'}) | follow[nt]
            else:
                predict[clave] = primeros
    
    return predict

gramatica = {
    'S': [['A', 'B', 'uno']],
    'A': [['dos', 'B'], ['ε']],
    'B': [['C', 'D'], ['tres'], ['ε']],
    'C': [['cuatro', 'A', 'B'], ['cinco']],
    'D': [['seis'], ['ε']]
}

first = calcular_first(gramatica)
follow = calcular_follow(gramatica, first)
predict = calcular_predict(gramatica, first, follow)

print("PREDICT:")
for k, v in predict.items():
    print(k, ":", v)