#EJERCICIO 1
def calcular_first(gramatica):
    first = {}
    
    for nt in gramatica:
        first[nt] = set()
    
    cambio = True
    
    while cambio:
        cambio = False
        
        for nt in gramatica:
            for prod in gramatica[nt]:
                
                i = 0
                while True:
                    simbolo = prod[i]
                    
                    if simbolo not in gramatica:
                        if simbolo not in first[nt]:
                            first[nt].add(simbolo)
                            cambio = True
                        break
                    
                    antes = len(first[nt])
                    first[nt] |= (first[simbolo] - {'ε'})
                    
                    if 'ε' not in first[simbolo]:
                        break
                    
                    if antes != len(first[nt]):
                        cambio = True
                    
                    i += 1
                    if i >= len(prod):
                        if 'ε' not in first[nt]:
                            first[nt].add('ε')
                            cambio = True
                        break
    
    return first


gramatica = {
    'S': [['A', 'B', 'uno']],
    'A': [['dos', 'B'], ['ε']],
    'B': [['C', 'D'], ['tres'], ['ε']],
    'C': [['cuatro', 'A', 'B'], ['cinco']],
    'D': [['seis'], ['ε']]
}

first = calcular_first(gramatica)

print("FIRST:")
for k, v in first.items():
    print(k, ":", v)